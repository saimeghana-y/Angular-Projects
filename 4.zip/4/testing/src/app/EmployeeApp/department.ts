export interface Deparment {
    id: number;
    name: string;
  }