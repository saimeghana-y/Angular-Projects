

export interface Employee {
    id: string;
    name: string;
    salary: number;
    permanent: true;
    joiningDate : Date;
  }